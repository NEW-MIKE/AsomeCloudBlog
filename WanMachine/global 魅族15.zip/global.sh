#!/system/bin/sh
echo "----------Meizu15 Global----------"
dd if=/dev/block/mmcblk0p35 of=/sdcard/devinfo_backup_$(date +%Y-%m-%d).img
echo -e '\x31' | dd of=/dev/block/mmcblk0p35 bs=1 seek=517 count=1
echo -e '\x32' | dd of=/dev/block/mmcblk0p35 bs=1 seek=517 count=1
echo -e '\x33' | dd of=/dev/block/mmcblk0p35 bs=1 seek=517 count=1
echo -e '\x34' | dd of=/dev/block/mmcblk0p35 bs=1 seek=517 count=1
echo -e '\x35' | dd of=/dev/block/mmcblk0p35 bs=1 seek=517 count=1
sleep 10
reboot recovery